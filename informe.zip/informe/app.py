import os
from flask import Flask, render_template, request, send_file
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from werkzeug.utils import secure_filename
from PIL import Image as PILImage

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def generate_pdf(data, antes_path, despues_path):
    filename = "informe.pdf"
    doc = SimpleDocTemplate(filename, pagesize=letter)
    
    styles = getSampleStyleSheet()
    
    # Estilos personalizados
    custom_style = ParagraphStyle(
        'ObservacionesStyle',
        parent=styles['BodyText'],
        spaceAfter=20
    )
    
    titulo_style = ParagraphStyle(
        'TituloStyle',
        parent=styles['Title'],
        fontSize=16,
        alignment=1,
        spaceAfter=20,
        fontName='Helvetica-Bold'
    )
    
    nota_style = ParagraphStyle(
        'NotaStyle',
        parent=styles['Italic'],
        textColor=colors.HexColor('#ED7D31'),
        alignment=1,
        spaceBefore=20,
        fontSize=12,
        fontName='Helvetica-Bold'
    )
    
    elements = []
    
    # Función para escalado proporcional
    def get_scaled_size(img_path, max_width=300, max_height=250):
        with PILImage.open(img_path) as img:
            width, height = img.size
            ratio = min(max_width/width, max_height/height)
            return width*ratio, height*ratio
    
    # Cargar logos
    logo_iberia = Image(os.path.join('static', 'images', 'iberia-logo.png'), width=120, height=60)
    logo_adp = Image(os.path.join('static', 'images', 'adp-logo.jfif'), width=100, height=50)
    
    # Encabezado con logos
    header_table = Table([
        [
            logo_adp,
            Paragraph("INFORME MERCADEO", titulo_style),
            logo_iberia
        ]
    ], colWidths=[150, 300, 150])
    
    header_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (0,0), 'LEFT'),
        ('ALIGN', (1,0), (1,0), 'CENTER'),
        ('ALIGN', (2,0), (2,0), 'RIGHT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 20)
    ]))
    
    elements.append(header_table)
    
    # Contenido principal
    content_data = []
    
    # Datos básicos
    content_data.append([
        Paragraph(f"<b>PDV:</b> {data['pdv']}<br/>"
                 f"<b>Categoría:</b> {data['categoria']}", 
                 styles['Normal'])
    ])
    
    # Imágenes con etiquetas
    antes_width, antes_height = get_scaled_size(antes_path)
    despues_width, despues_height = get_scaled_size(despues_path)
    
    img_table = Table([
        [
            Image(antes_path, width=antes_width, height=antes_height),
            Image(despues_path, width=despues_width, height=despues_height)
        ],
        [
            Paragraph("<b>ANTES</b>", styles['Normal']),
            Paragraph("<b>DESPUÉS</b>", styles['Normal'])
        ]
    ], colWidths=[300, 300])
    
    img_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,0), 10),
        ('LEADING', (0,0), (-1,-1), 14)
    ]))
    
    content_data.append([img_table])
    
    # Observaciones
    content_data.append([
        Paragraph("<b>Observaciones:</b><br/>" + data['observaciones'], custom_style)
    ])
    
    # Tabla de productos
    table_data = [["Producto", "Caras después", "Participación (%)", "Inventario"]]
    for row in zip(data['producto'], data['caras_despues'], data['participacion'], data['inventario']):
        table_data.append(list(row))
    
    product_table = Table(table_data)
    product_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#ED7D31')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 10),
        ('BOTTOMPADDING', (0,0), (-1,0), 12),
        ('BACKGROUND', (0,1), (-1,-1), colors.HexColor('#FCECE8')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#FFFFFF'))
    ]))
    
    content_data.append([product_table])
    
    # Nota al pie
    content_data.append([
        Paragraph('<i>¡Con Iberia tu comida gana en sabor!</i>', nota_style)
    ])
    
    # Tabla principal
    main_table = Table(content_data, colWidths=[600])
    main_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10)
    ]))
    
    elements.append(main_table)
    
    doc.build(elements)
    return filename

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        data = {
            'pdv': request.form['pdv'],
            'categoria': request.form['categoria'],
            'observaciones': request.form['observaciones'],
            'producto': request.form.getlist('producto[]'),
            'caras_despues': request.form.getlist('caras_despues[]'),
            'participacion': request.form.getlist('participacion[]'),
            'inventario': request.form.getlist('inventario[]')
        }
        
        antes_file = request.files['antes']
        despues_file = request.files['despues']
        
        antes_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(antes_file.filename))
        despues_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(despues_file.filename))
        
        antes_file.save(antes_path)
        despues_file.save(despues_path)
        
        pdf_path = generate_pdf(data, antes_path, despues_path)
        return send_file(pdf_path, as_attachment=True)
    
    return render_template('index.html')

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)